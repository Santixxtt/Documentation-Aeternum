# Frontend (React + Vite)

Instalar dependencias:

```bash
npm install
```

Iniciar proyecto:

```bash
npm run dev
```

Acceso en navegador: http://localhost:5173