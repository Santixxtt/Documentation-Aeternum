# Instalación y Requisitos

Requisitos:

- Python 3.11+
- Node.js 20+
- MySQL o Railway
- Redis

Clonar repositorio:

```bash
git clone https://github.com/Santixxtt/Aeternum.git
```