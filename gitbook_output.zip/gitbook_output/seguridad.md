# Seguridad

- Autenticación JWT
- Roles: Usuario / Bibliotecario
- Hash de contraseñas (bcrypt)
- Tokens de recuperación
- Protección de rutas